async function getInfo() {
  let inputElement = document.getElementById("stopId");
  let divElement = document.getElementById("stopName");
  let ulElement = document.getElementById("buses");

  try {
    let busURL = await fetch(
      `http://localhost:3030/jsonstore/bus/businfo/${inputElement.value}`
    );
    let data = await busURL.json();
    ulElement.innerHTML = "";
    divElement.textContent = data.name;
    Object.entries(data.buses).forEach(([busId, time]) => {
      let liElement = document.createElement("li");
      liElement.textContent = `Bus ${busId} arrives in ${time} minutes`;
      ulElement.appendChild(liElement);
    });
  } catch (error) {
    ulElement.innerHTML = "";
    divElement.textContent = "Error";
  }
}

//--------------promises-----------------------------
// function getInfo() {
//     //1.get all elements by id
//     //2. fetch data from server
//     //3. forEach bus create li element with text
//     //4. append li tags to ul
//     let busURL = "http://localhost:3030/jsonstore/bus/businfo";
//     let inputElement = document.getElementById("stopId");
//     let ulElement = document.getElementById("buses");
//     let divElement = document.getElementById("stopName");

//     fetch(`${busURL}/${inputElement.value}`)
//       .then((response) => response.json())
//       .then((data) => {
//         let buses = data.buses;
//         let name = data.name;

//         divElement.textContent = name;
//         ulElement.innerHTML = "";
//         Object.keys(buses).forEach((bus) => {
//           let liElement = document.createElement("li");
//           liElement.textContent = `Bus ${bus} arrives in ${buses[bus]} minutes`;
//           ulElement.appendChild(liElement);
//         });
//       })
//       .catch((error) => {
//         divElement.textContent = "Error";
//         ulElement.innerHTML = "";
//       });
//   }
